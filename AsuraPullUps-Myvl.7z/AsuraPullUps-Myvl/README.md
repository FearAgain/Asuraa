</div>
DISCLAIMER: I am not responsible for any damages or malicious use of this macro<br>
This macro's purpose is strictly only for Asura roblox<br>
I am not responsible for any Malicious software you may have downloaded<br>
in the process of installing the macro, make sure you download only from official websites<br>
This macro is open source and can be read for others therefore has no malicious intent<br>
if by anychance the software triggers Windows Security or Antivirus softwares<br>
Immediately halt the software and remove from your device<br>
</div>

<div align="center">
<h1>AsuraPullUps</h1>
</div>
<br>

<div align="center">
<br>
<br>
An Open-Source macro for Asura<br>
Mainly for Pull Ups as of now but will add other features as well<br>
ALL FOR FREE!<br>
My Discord is jash2260 dm if you need help<br>
  before dm'ing me make sure <b>DO NOT USE MICROSOFT STORE ROBLOX</b> <br>
Video Instruction: https://youtu.be/35pktsCUpk4?si=gsRZwqg0zNdoptom<br>
<br>
  To download the file just click the Green button that says CODE<br>
  Download the zip file and unzip the file<br>
  then follow the video or instructions below<br>
<br>
<b>INSTRUCTIONS:</b>
<br>
You will need to download AutoHotkey V1.1 for this to work https://www.autohotkey.com/<br>
After downloading it<br>
You will need to Open the Script and stand near a Pull up bar<br>
Click on the pull up bar and then the pull up bar leave<br>
and then hover your mouse at the pull up bar<br>
then press 'k' this should start the macro<br>
The macro has auto eat so don't worry just make sure you have full hunger bar<br>
This Macro is suited for all resolutions(maybe)<br>
  <b>DO NOT USE MICROSOFT STORE ROBLOX</b> <br>
<br>



<b>Self-Troubleshooting:</b><br>
MISSING DURA IMAGE: turn off Fullscreen mode<br>
If it keeps saying missing dura image make sure to change your display settings to these<br>
![image](https://github.com/nissanSilviaa/AsuraPullUps/assets/114170790/f2ca2071-636d-4bf5-ae6f-624eb345ccdb)<br>
however macro should work for all resolutions if it doesnt work keep changing into different resolutions<br>
![image](https://github.com/nissanSilviaa/AsuraPullUps/assets/114170790/ab3a60ae-c25e-4cd2-bd02-167217f6d769)<br>
<br>
Roblox chat is not closed, just click on the chat icon on the top left and it should work fine<br>
Hunger Bar not full might potentially cause the macro to freak out<br>
If it says you have no food but you have food try sorting your food inventory in this chronological order<br>
![image](https://github.com/nissanSilviaa/AsuraPullUps/assets/114170790/8bc1c719-dbad-498d-b6a9-28d3a7aef604)<br>

<b>NOTE:</b>I quit asura so if the macro doesn't work then bad luck<br>

<br>
Jash's Macro Software

This software is freely distributed under the terms of the GNU General Public License as published by the Free Software Foundation, either version 2.0 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this program. If not, see <http://www.gnu.org/licenses/>.

<b>This software is provided "as is" and does not grant any rights to steal, modify, or distribute the code under anyone's name without compliance with the terms of the GNU General Public License.</b><br>
This macro is license under this github account as Josh (nissanSilviaa) https://github.com/nissanSilviaa<br>

</div>

